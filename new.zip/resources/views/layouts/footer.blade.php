<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        Version 1.4.0
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2022 Made with ❤️ by <a href="https://twitter.com/@oggiesutrisna">Oggie
            Sutrisna</a></strong>
</footer>
