@extends('layouts.app')

@section('content')

<h2>
    LOL!
</h2>

@endsection
