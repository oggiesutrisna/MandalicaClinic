<nav class="navbar navbar-light navbar-expand-md py-3">
        <div class="container"><a class="navbar-brand d-flex align-items-center"
                href="https://wa.me/6282298298911"><span
                    class="bs-icon-sm fa-solid fa-phone bs-icon-rounded bs-icon-primary d-flex justify-content-center align-items-center me-2 bs-icon"
                    style="background: var(--bs-red);">
                </span><span>Call Center</span></a><button data-bs-toggle="collapse" class="navbar-toggler"
                data-bs-target="#navcol-2"><span class="visually-hidden">Toggle navigation</span><span
                    class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navcol-2">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <div class="btn-toolbar">
                            <div class="btn-group" role="group"
                                style="color: var(--bs-blue);background: var(--bs-red);"><a class="btn btn-primary"
                                    type="button" href="https://www.facebook.com/mandalicaclinic"
                                    style="background: var(--bs-red);border-color: var(--bs-red);">
                                    <i class="fa-brands fa-facebook-f"></i>
                                </a><a class="btn btn-primary" type="button"
                                    href="https://instagram.com/klinikmandalica?igshid=YmMyMTA2M2Y="
                                    style="background: var(--bs-red);border-color: var(--bs-red);">
                                    <i class="fa-brands fa-instagram"></i>
                                </a></div>
                            <div class="btn-group" role="group"><a class="btn btn-primary" href="" type="button"
                                    style="background: var(--bs-red);border-color: var(--bs-red);"><i
                                        class="fa-brands fa-google"></i></a>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
